<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Propiedades;
use Faker\Generator as Faker;

$factory->define(Propiedades::class, function (Faker $faker) {
    return [
        'inmobiliaria_id' =>  rand(1, 2),
		'estadoPropiedad_id' =>  rand(1, 2),
		'direccion' =>  $faker->streetAddress,
		'titulo' => $faker->title,
		'caracteristica' =>  $faker->text($maxNbChars = 100),
		'imagen' => $faker->image('public/imagen', 640, 480, 'cats', false),
		'precio' =>  $faker->randomFloat(2, 0, 10000)
    ];
});
