<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Propiedades;
use App\Models\Inmobiliarias;

class PropiedadesController extends Controller
{
    public function todasLasPropiedades()
    {
    	$propiedades = Propiedades::all();
    	$title = "Todas las propiedades";
    	return view('contenido.propiedades', compact('propiedades', 'title'));
    }

    public function propiedadesPorInmobiliaria($inmobiliaria)
    {
    	$title = "Propiedades en $inmobiliaria";
    	$inmobiliarias = Inmobiliarias::where('descripcion', '=', $inmobiliaria)->first();
    	$propiedades = $inmobiliarias->propiedades()->get();
    	return view('contenido.propiedades', compact('propiedades', 'title'));
    }
}
