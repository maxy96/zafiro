<footer class="page-footer indigo darken-4">
  <div class="container">
    <div class="row">
      <div class="col l6 s12">
        <h5 class="white-text">Contenidos de zafiro</h5>
        <p class="purple-text text-lighten-4">Contenidos sobre zafiro como contactos, administradores, terminos y condiciones, privacidad, contactos, etc. </p>
        <h6 class="grey-text">Recuerde que esto es una demo.</h6>
      </div>
      <div class="col l4 offset-l2 s12">
        <h5 class="white-text">Links</h5>
        <ul>
          <li><a class="pink-text text-lighten-4" href="#!">Sobre zafiro</a></li>
          <li><a class="pink-text text-lighten-4" href="#!">Sobre nosotros</a></li>
          <li><a class="pink-text text-lighten-4" href="#!">Contactos</a></li>
          <li><a class="pink-text text-lighten-4" href="#!">Administradores</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-copyright">
    <div class="container">
      © 2014 Copyright Text
      <a class="red-text text-lighten-3 right" href="#!">More Links</a>
    </div>
  </div>
</footer><?php /**PATH C:\laragon\www\zafiro\resources\views/layouts/footer.blade.php ENDPATH**/ ?>