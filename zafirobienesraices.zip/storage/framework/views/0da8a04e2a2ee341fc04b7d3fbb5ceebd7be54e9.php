
<?php $__env->startSection('title', 'Gestion de propiedades'); ?>
<?php $__env->startPush('styles'); ?>

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="" id="app">
	<gestionar-propiedades></gestionar-propiedades>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/gestionarPropiedades.js')); ?>"></script>
<script>
	$(document).ready(function(){
		$('.modal').modal();
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zafiro\resources\views/admin/gestionarPropiedades.blade.php ENDPATH**/ ?>