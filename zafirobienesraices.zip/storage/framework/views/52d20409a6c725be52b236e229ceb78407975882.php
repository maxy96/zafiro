
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="card-panel pink darken-1">
		<h5 class="center-align white-text">PUBLICADOS</h5>
	</div>
	<div class="row">
		<?php $__currentLoopData = $propiedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $propiedad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col m3">
			<div class="card hoverable">
				<div class="card-image">
					<img src="<?php echo e(asset("imagen/$propiedad->imagen")); ?>">
					<a class="btn-floating halfway-fab waves-effect waves-light purple"><i class="material-icons">phone</i></a>
				</div>
				<div class="card-content ">
					<small class="grey-text"><?php echo e($propiedad->inmobiliaria()->first()->descripcion); ?></small>
					<span class="card-title pink-text darken-4"><?php echo e($propiedad->titulo); ?></span>
					<p class=""><?php echo e(\Str::limit($propiedad->caracteristica, $limit = 55, $end = '...')); ?></p>
				</div>
				<div class="card-action">
					<a href="#" class="btn waves-effect waves-light pink radius">Ver mas</a>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zafiro\resources\views/contenido/propiedades.blade.php ENDPATH**/ ?>