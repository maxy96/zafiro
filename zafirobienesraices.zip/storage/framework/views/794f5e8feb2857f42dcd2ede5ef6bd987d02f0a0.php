<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="navbar-fixed">
        <nav class="purple darken-4">
            <div class="nav-wrapper container-fluid ">
              <a href="<?php echo e(route('welcome')); ?>" class="brand-logo">
                <img class="nav-logo" src="<?php echo e(asset('logo-navbar-blanco.png')); ?>" alt="">
            </a>
            <ul id="nav-mobile" class="right hide-on-med-and-down">
                <?php if(auth()->guard()->guest()): ?>
                <li>
                    <a href="<?php echo e(route('register')); ?>"><i class="material-icons left">person_add</i>Registrarse</a>
                </li>
                <li> 
                    <a href="<?php echo e(route('login')); ?>"><i class="material-icons left">exit_to_app</i>Iniciar sesion</a>
                </li>
                <?php else: ?>
                <li>
                    <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="material-icons left">logout</i><?php echo e(__('Cerrar sesion')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
                <?php endif; ?>
                <li>
                    <a href="#" data-target="slide-out" class="sidenav-trigger" style="display: block;">
                        <i class="material-icons left">menu</i><?php echo e(__('Menu')); ?>

                    </a>
                </li>
            </ul>
            <a href="#" data-target="slide-out" class="right sidenav-trigger" >
                <i class="material-icons">menu</i>
            </a>   
        </div>
    </nav>
</div>   
<?php echo $__env->make('navegation.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('content'); ?>

<?php echo $__env->make('layouts.floatButton', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\zafiro\resources\views/layouts/app.blade.php ENDPATH**/ ?>