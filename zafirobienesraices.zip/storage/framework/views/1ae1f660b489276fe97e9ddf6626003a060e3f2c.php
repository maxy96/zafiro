<?php $__env->startSection('title', 'Bienvenido a zafiro'); ?>
<?php $__env->startSection('content'); ?>
<div class="slider fullscreen">
    <ul class="slides">
      <li>
        <img src="<?php echo e(asset('welcome-image/caro1.jpg')); ?>"> <!--  image -->
      </li>
      <li>
        <img src="<?php echo e(asset('welcome-image/caro2.jpg')); ?>"> <!--  image -->
      </li>
      <li>
        <img src="<?php echo e(asset('welcome-image/caro3.jpg')); ?>"> <!--  image -->
      </li>
      <li>
        <img src="<?php echo e(asset('welcome-image/caro4.jpg')); ?>"> <!--  image -->
      </li>
    </ul>
</div>
<div class="center welcome">
    <img src="<?php echo e(asset('logo-principal.png')); ?>" class="logo-welcome" alt="">
    <h4 class="indigo-text">Esto es una demo</h4>
    <h5 class="purple-text darken-text-4">Pagina web en desarrollo</h5>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  <script>
    $(document).ready(function(){
      $('.slider').slider({
        indicators: false,
        interval: 2500
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zafiro\resources\views/welcome.blade.php ENDPATH**/ ?>