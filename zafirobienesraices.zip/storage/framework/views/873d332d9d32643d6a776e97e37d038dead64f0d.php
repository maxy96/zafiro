<ul id="slide-out" class="sidenav">
	<li>
		<div class="user-view">
			<div class="background">
				<img class="h100 w100" src="<?php echo e(asset('wallpaper.jpg')); ?>">
			</div>
			<i class="material-icons white-text">account_circle</i>
			<?php if(auth()->guard()->guest()): ?>
			<a href="#"><span class="white-text name">Invitado</span></a>
			<?php else: ?>
			<a href="#"><span class="white-text name"><?php echo e(Auth::user()->nombre." ".Auth::user()->apellido); ?></span></a>
			<a href="#"><span class="white-text email"><?php echo e(Auth::user()->email); ?></span></a>
			<?php endif; ?>
		</div>
	</li>
	<li><a class="subheader">CONTENIDO</a></li>
	<li>
		<a class="dropdown-trigger btn waves-effect purple darken-4 radius" href='#' data-target='dropdown1'>Propiedades</a>
		<!-- Dropdown Structure -->
		<ul id='dropdown1' class="dropdown-content">
			<li><a class="purple-text text-darken-4" href="<?php echo e(route('propiedades.todos')); ?>">Todos</a></li>
			<?php $__currentLoopData = App\Models\Inmobiliarias::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmobiliaria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><a class="purple-text text-darken-4" href="<?php echo e(route('propiedades.inmobiliaria', $inmobiliaria->descripcion)); ?>"><?php echo e($inmobiliaria->descripcion); ?></a></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</li>
	<li><a href="#" class="btn waves-effect purple darken-4 disabled radius">Mapa</a></li>

	<li><div class="divider"></div></li>
	<li><a class="subheader">SOLO ADMINISTRADOR</a></li>
	<li><a class="waves-effect btn disabled radius" href="#">Vencimientos</a></li>
	<li><a class="waves-effect btn pink darker-4 radius" href="<?php echo e(route('admin.gestionarPropiedades')); ?>">Gestionar propiedades</a></li>

	<li><div class="divider"></div></li>
	<?php if(auth()->guard()->guest()): ?>
	<li><a class="subheader">IDENTIFICARSE</a></li>
	<li><a href="<?php echo e(route('login')); ?>" class="btn waves-effect radius indigo darker-4"><?php echo e(__('Iniciar sesion')); ?></a></li>
	<li><a href="<?php echo e(route('register')); ?>" class="btn waves-effect radius indigo darker-4"><?php echo e(__('Registro')); ?></a></li>
	<?php else: ?>
	<li><a class="subheader">CERRAR SESION</a></li>
	<li>
		<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" class="btn waves-effect radius indigo darker-4"><?php echo e(__('Cerrar sesion')); ?>

		</a>
		<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
        </form>
	</li>
	<?php endif; ?>
</ul>

<?php $__env->startPush('scripts'); ?>
<script>
	$(function(){
		$('.dropdown-trigger').dropdown({
			alignment: 'left',
		});
	});
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\zafiro\resources\views/navegation/sidenav.blade.php ENDPATH**/ ?>