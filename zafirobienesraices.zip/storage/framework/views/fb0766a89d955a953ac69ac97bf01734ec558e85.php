<?php $__env->startSection('title', 'Iniciar sesion'); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt20 mb20">
    <div class="row">
        <div class="col s12 m6 offset-m3">
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-title center pt2" style="border-bottom: 1px solid #eeeeee;">
                        <h4 class="robotoSlab purple-text darken-text-2">Iniciar sesion</h4>
                    </div>
                    <div class="card-content pl30 pr30 pb0">
                        <div class=" row">
                            <div class="input-field col m12 s12">
                              <i class="material-icons prefix">mail_outline</i>
                              <input id="email" type="email" name="email" class="validate">
                              <label for="email">Email</label>
                          </div>
                          <div class="input-field col m12 s12">
                              <i class="material-icons prefix">lock_outline</i>
                              <input id="password" type="password" name="password" class="validate">
                              <label for="password">Contraseña</label>
                          </div>
                          <div class="center col s12">
                              <label>
                                <input type="checkbox" name="remember" id="remember">
                                <span>Recordarme</span>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="card-action">
                    <div class="center">
                        <button type="submit" class="btn btn-primary mb10">
                            <?php echo e(__('Iniciar sesion')); ?>

                        </button>
                        <br>
                        <?php if(Route::has('password.request')): ?>
                        <a class="indigo-text waves-effect" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zafiro\resources\views/auth/login.blade.php ENDPATH**/ ?>