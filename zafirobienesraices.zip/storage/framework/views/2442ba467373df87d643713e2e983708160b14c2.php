
<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col m3">
			<div class="card">
				<div class="card-image">
					<img src="<?php echo e(asset('welcome-image/caro6.jpg')); ?>">
					<a class="btn-floating halfway-fab waves-effect waves-light purple"><i class="material-icons">phone</i></a>
				</div>
				<div class="card-content">
					<span class="card-title">Card Title</span>
					<p>I am a very simple card. I am good at containing small bits of information.
					I am convenient because I require little markup to use effectively.</p>
				</div>
				<div class="card-action">
					<button class="btn waves-effect waves-light pink">Ver mas </button>
				</div>
			</div>
		</div>
		<div class="col m3">
			<div class="card">
				<div class="card-image">
					<img src="<?php echo e(asset('welcome-image/caro6.jpg')); ?>">
					<a class="btn-floating halfway-fab waves-effect waves-light purple"><i class="material-icons">phone</i></a>
				</div>
				<div class="card-content">
					<span class="card-title">Card Title</span>
					<p>I am a very simple card. I am good at containing small bits of information.
					I am convenient because I require little markup to use effectively.</p>
				</div>
				<div class="card-action">
					<button class="btn waves-effect waves-light pink">Ver mas </button>
				</div>
			</div>
		</div>
		<div class="col m3">
			<div class="card">
				<div class="card-image">
					<img src="<?php echo e(asset('welcome-image/caro6.jpg')); ?>">
					<a class="btn-floating halfway-fab waves-effect waves-light purple"><i class="material-icons">phone</i></a>
				</div>
				<div class="card-content">
					<span class="card-title">Card Title</span>
					<p>I am a very simple card. I am good at containing small bits of information.
					I am convenient because I require little markup to use effectively.</p>
				</div>
				<div class="card-action">
					<button class="btn waves-effect waves-light pink">Ver mas </button>
				</div>
			</div>
		</div>
		<div class="col m3">
			<div class="card">
				<div class="card-image">
					<img src="<?php echo e(asset('welcome-image/caro6.jpg')); ?>">
					<a class="btn-floating halfway-fab waves-effect waves-light purple"><i class="material-icons">phone</i></a>
				</div>
				<div class="card-content">
					<span class="card-title">Card Title</span>
					<p>I am a very simple card. I am good at containing small bits of information.
					I am convenient because I require little markup to use effectively.</p>
				</div>
				<div class="card-action">
					<button class="btn waves-effect waves-light pink">Ver mas </button>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\zafiro\resources\views/contenido/publicados.blade.php ENDPATH**/ ?>