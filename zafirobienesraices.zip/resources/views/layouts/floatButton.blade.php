<div class="fixed-action-btn">
  <a class="btn-floating btn-large green" href="https://wa.me/5493794087107?text=Quisiera%20obtener%20mas%20informacion" target="_blank">
    <i class="large fa fa-whatsapp"></i>
  </a>
</div>