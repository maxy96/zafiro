@extends('layouts.app')
@section('title', $title)
@section('content')
<div class="container">
	<div class="card-panel pink darken-1">
		<h5 class="center-align white-text">PUBLICADOS</h5>
	</div>
	<div class="row">
		@foreach($propiedades as $propiedad)
		<div class="col m3">
			<div class="card hoverable">
				<div class="card-image">
					<img src="{{asset("imagen/$propiedad->imagen")}}">
					<a class="btn-floating halfway-fab waves-effect waves-light purple"><i class="material-icons">phone</i></a>
				</div>
				<div class="card-content ">
					<small class="grey-text">{{$propiedad->inmobiliaria()->first()->descripcion}}</small>
					<span class="card-title pink-text darken-4">{{$propiedad->titulo}}</span>
					<p class="">{{\Str::limit($propiedad->caracteristica, $limit = 55, $end = '...')}}</p>
				</div>
				<div class="card-action">
					<a href="#" class="btn waves-effect waves-light pink radius">Ver mas</a>
				</div>
			</div>
		</div>
		@endforeach
	</div>
</div>
@endsection