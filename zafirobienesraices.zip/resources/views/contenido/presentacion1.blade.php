<div class="container">
    <img src="{{asset('logo-principal.png')}}" class="logo-welcome" alt="">
    <div class="carousel">
        <a class="carousel-item" href="#one!"><img src="{{asset('welcome-image/caro1.jpg')}}"></a>
        <a class="carousel-item" href="#two!"><img src="{{asset('welcome-image/caro2.jpg')}}"></a>
        <a class="carousel-item" href="#three!"><img src="{{asset('welcome-image/caro3.jpg')}}"></a>
        <a class="carousel-item" href="#four!"><img src="{{asset('welcome-image/caro4.jpg')}}"></a>
        <a class="carousel-item" href="#five!"><img src="{{asset('welcome-image/caro5.jpg')}}"></a>
    </div>
</div>