@extends('layouts.app')
@section('title', 'Gestion de propiedades')
@push('styles')

@endpush
@section('content')
<div class="" id="app">
	<gestionar-propiedades></gestionar-propiedades>
</div>
@endsection
@push('scripts')
<script src="{{asset('js/gestionarPropiedades.js')}}"></script>
<script>
	$(document).ready(function(){
		$('.modal').modal();
	});
</script>
@endpush