<template>

	<div class="container z-depth-2 white p20 mt20 mb20">
		<a class="waves-effect waves-light btn modal-trigger purple" href="#nuevaPropiedad"><i class="material-icons">add</i></a>

		<!-- Modal Structure -->
		<div id="nuevaPropiedad" class="modal">
			<form @submit.prevent="addNewPropiedad"  enctype="multipart/form-data">
				<div class="modal-content">
					<h4>Nueva propiedad</h4>
					<div class="row">
						<div class="col s12">
							<label v-for="inmobiliaria in inmobiliarias">
								<input class="with-gap" v-model="newPropiedad.inmobiliaria" name="inmobiliaria" v-bind:value="inmobiliaria.id_inmobiliaria" type="radio" />
								<span>{{inmobiliaria.descripcion}}</span>
							</label>
						</div>
						<div class="input-field col s6">
							<input id="direccion" v-model="newPropiedad.direccion"  type="text" class="validate">
							<label for="direccion">Direccion</label>
						</div>

						<div class="input-field col s6">
							<input id="titulo" v-model="newPropiedad.titulo" type="text" class="validate">
							<label for="titulo">Titulo</label>
						</div>
						<div class="input-field col s12">
							<textarea id="caracteristica" v-model="newPropiedad.caracteristicas" class="materialize-textarea"></textarea>
							<label for="caracteristica">Caracteristicas</label>
						</div>
						<div class="input-field file-field col s6">
							<div class="btn">
								<span>Imagen</span>
								<input @change="obtenerImagen" type="file" accept="image/*" ref="fileImage" required>
							</div>
							<div class="file-path-wrapper">
								<input class="file-path validate" type="text">
							</div>
						</div>
						<div class="input-field col s6">
							<input id="precio" v-model="newPropiedad.precio" type="number" class="validate">
							<label for="precio">Precio</label>
						</div>
					</div>
				</div>
				<div class="modal-footer ">
					<button type="submit" class="btn-flat waves-effect waves-light modal-close ">
                            Guardar<i class="material-icons right">send</i>
                    </button>
				</div>
			</form>
		</div>
		
		<!-- Filter Structure -->
		<div class="row mt10">
			<div class="input-field col s10">
				<input id="buscar" type="text" v-model="tableData.search"
				@input="getPropiedades()">
				<label for="Buscar">Buscar</label>
			</div>
			<div class="input-field col s2">
				<div class="select">
					<select v-model="tableData.length" @change="getPropiedades()">
						<option v-for="(records, index) in perPage" :key="index" :value="records">{{records}}</option>
					</select>
				</div>
			</div>
		</div>
		<datatable :columns="columns" :sortKey="sortKey" :sortOrders="sortOrders" @sort="sortBy">
			<tbody>
				<tr v-for="propiedad in propiedades" :key="propiedad.id_propiedad">
					<td><img :src="`/imagen/${propiedad.imagen}`" height="60px" width="60px"></td>
					<td>{{propiedad.direccion}}</td>
					<td>{{propiedad.titulo}}</td>
					<td>{{propiedad.precio}}</td>
				</tr>
			</tbody>
		</datatable>
		<pagination :pagination="pagination"
		@prev="getPropiedades(pagination.prevPageUrl)"
		@next="getPropiedades(pagination.nextPageUrl)">
	</pagination>
</div>
</template>
<script>
import Datatable from './Datatable.vue';
import Pagination from './Pagination.vue';
export default{
	components: { datatable: Datatable, pagination: Pagination },
	created() {
		this.getPropiedades();
		this.getInmobiliarias();
	},
	data() {
		let sortOrders = {};

		let columns = [
		{width: '33%', label: 'Imagen', name: 'imagen' },
		{width: '33%', label: 'Direccion', name: 'direccion' },
		{width: '33%', label: 'Titulo', name: 'titulo'},
		{width: '33%', label: 'Precio', name: 'precio'}
		];

		columns.forEach((column) => {
			sortOrders[column.name] = -1;
		});
		return {
			inmobiliarias: [],
			propiedades: [],
			columns: columns,
			sortKey: 'direccion',
			sortOrders: sortOrders,
			perPage: ['10', '20', '30'],
			tableData: {
				draw: 0,
				length: 10,
				search: '',
				column: 0,
				dir: 'desc',
			},
			newPropiedad:{
				inmobiliaria: '',
				estado: 1,
				direccion: '',
				titulo:'',
				caracteristicas:'',
				imagen: '',
				precio: ''
			},

			pagination: {
				lastPage: '',
				currentPage: '',
				total: '',
				lastPageUrl: '',
				nextPageUrl: '',
				prevPageUrl: '',
				from: '',
				to: ''
			},
		}
	},

	methods: {
		getInmobiliarias(url = '/api/v1/inmobiliarias'){
			axios.get(url).then(response => {
				this.inmobiliarias = response.data;
			});
		},
		getPropiedades(url = '/api/v1/propiedades'){
			this.tableData.draw++;
			axios.get(url, {params: this.tableData})
			.then(response => {
				let data = response.data;
				if (this.tableData.draw == data.draw) {
					this.propiedades = data.data.data;
					this.configPagination(data.data);
				}
			})
			.catch(errors => {
				console.log(errors);
			});
		},

		addNewPropiedad(){
			let formData = new FormData();
				formData.append('inmobiliaria_id', this.newPropiedad.inmobiliaria)
				formData.append('estadoPropiedad_id', 1)
				formData.append('direccion', this.newPropiedad.direccion)
				formData.append('titulo', this.newPropiedad.titulo)
				formData.append('caracteristicas', this.newPropiedad.caracteristicas)
				formData.append('imagen', this.newPropiedad.imagen)
				formData.append('precio', this.newPropiedad.precio)
			axios.post('/api/v1/propiedades', formData).then(response => {
				this.getPropiedades();
				toastr.success('Nueva propiedad agregada');
			})
			.catch(error => {
				console.log(error.data);
			});
		},

		configPagination(data) {
			this.pagination.lastPage = data.last_page;
			this.pagination.currentPage = data.current_page;
			this.pagination.total = data.total;
			this.pagination.lastPageUrl = data.last_page_url;
			this.pagination.nextPageUrl = data.next_page_url;
			this.pagination.prevPageUrl = data.prev_page_url;
			this.pagination.from = data.from;
			this.pagination.to = data.to;
		},

		sortBy(key) {
			this.sortKey = key;
			this.sortOrders[key] = this.sortOrders[key] * -1;
			this.tableData.column = this.getIndex(this.columns, 'name', key);
			this.tableData.dir = this.sortOrders[key] === 1 ? 'asc' : 'desc';
			this.getPropiedades();
		},

		getIndex(array, key, value) {
			return array.findIndex(i => i[key] == value)
		},

		obtenerImagen(e){
				let file = e.target.files[0];
				let fileReader = new FileReader();
				fileReader.readAsDataURL(file);
				
				fileReader.onload = (e) =>{
					this.newPropiedad.imagen = e.target.result;
					//this.editProducto.editImagen = e.target.result;
					//this.editProducto.imagenPrevia = e.target.result;
				}
			}, //end obtenerImagen

	}
}
</script>