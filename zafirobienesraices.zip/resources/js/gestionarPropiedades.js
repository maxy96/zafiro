Vue.component('gestionar-propiedades', require('./components/GestionarPropiedades.vue').default);

const app = new Vue({
    el: '#app',
});
